package net.sansan.tutorial.item;

public interface ItemOreDict {
	
	void initOreDict();

}
